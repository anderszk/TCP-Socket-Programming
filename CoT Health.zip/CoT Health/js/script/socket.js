
//Variabler og konstanter
/*-----------------------------------------------------------------------------------------------------*/
var socket = io.connect('192.168.43.19:2520', {secure: false}); //This line declares a socket.io object to var "socket" and connects to the server
//The "secure: false" tells if the connection will be encrypted or not. Since we will not encrypt our connections, this is false.
let json = {};

var bar1 = document.getElementById("very-weak");
var bar2 = document.getElementById("weak");
var bar3 = document.getElementById("strong");
var bar4 = document.getElementById("pretty-strong");

let device1_home = "";
let device1_connection = "";
let device1_type = "";

let device2_home = "";
let device2_connection = "";
let device2_type = "";

let device3_home = "";
let device3_connection = "";
let device3_type = "";

let device4_home = "";
let device4_connection = "";
let device4_type = "";

let peakbpm = 0;
let peakhigh = 0;
let peaklow = 0;


//Connection-funksjoner
/*-----------------------------------------------------------------------------------------------------*/
socket.on('connect',function() { //When you connect to the server (and it works) call this function
    console.log('Client has connected to the server!'); //The client prints this message
});

socket.on('clientConnected',function(id, ip) { //This is our selfmade functions. Here we can have the server return arguments (data) that we need
    console.log('Client recevied ID: ' + id); //In this case the server will tell us what our local ID is (auto assigned)
    console.log("Client IP: " + ip);//And it will tell us what our IP-address
});


/*
//In this function (which is essentially built up the same as a void function in Arduino) we want to send something to the server
//For this we use the other important Socket.io function, .emit(arg). Here we are telling our socket object so call the "changeLEDState" function
//on the server with the "state" argument. By calling the function on the server we mean that we send data to the server that tells it to do something
function changeLEDState(state) {
    //This function controls wether a LED-light is on or of
    socket.emit('changeLEDState', state); //Here the actual socket-object function is called. If we want a response we will have to set up a function (.on) like earlier.
    console.log("changeLEDState called");

}

function changeDriveState(state) {

    socket.emit('changeDriveState', state); //Same logic as earlier, this calls the change of motor direction
    console.log("changeDriveState called");

}

function changeTurnState(state) {

    socket.emit('changeTurnState', state);
    console.log("changeTurnState called");

}

function changeStopState(state) {

    socket.emit('changeStopState', state);
    console.log("changeStopState called");

}

function sendBuzzer(state) {
    socket.emit('buzz', state);
    console.log("Buzz-signal sent to ESP32!");
}
 */



//Disse funksjonene er kommmentert ut på bakgrunn av at vi har velgt å gå for en annen lønsning der dataen blir sendt
//Så fort brukren kommer inn på nettsiden.
/*-----------------------------------------------------------------------------------------------------
function requestDataFromBoard(interval) {
    socket.emit('requestDataFromBoard', interval); //Here we tell the server to call the function "requestDataFromBoard" with a argument called "intervall"
    //The intervall value is the period of time between each data transmit from the ESP32 to the server. Typical values can be everything form 100ms to 100s
    console.log("requestDataFromBoard was called with intervall: " + interval);
} //Be careful to not set the interval value to low, you do not want to overflood your server with data/requests

function stopDataFromBoard() { //Tells the server to stop all timers so that data is no longer sent from the ESP32 to the webpage
    socket.emit('stopDataFromBoard'); //Here we tell the server to call the function "stopDataFromBoard"
    console.log("stopDataFromBoard was called");
}
*/

/*

function user_on (data) {
    if (data === 1) {
        user_wear = "The user is wearing the device!";
        console.log("User active")
    }
    else if (data === 0) {
        user_wear = "The user is not wearing the device!";
        console.log("User inactive")
    }
    else {
        console.log("Something went wrong!");
    }
    document.getElementById("status").innerHTML = user_wear
}

*/



//Receives all data in JSON. In this way were able to extract the information effective and it also synchronize data and save space :)

socket.on('data', function(data){
    console.log(JSON.stringify(data))

    dataArr1.push(data.temp);
    dataArr1.shift();
    label1.push(getTime());
    label1.shift()
    dataArr4.push(data.humidity);
    dataArr4.shift();
    myLineChart.update();

    dataArr2.push(data.bpm);
    dataArr2.shift()
    label1.push(getTime());
    label1.shift()
    myLineChart2.update()

    lon = data.gps.longitude;
    //console.log(lon)
    lat = data.gps.latitude;
    //console.log(lat)

    var warning = data.prewarn;

    wear = data.wear;
    //user_on(wear);
    //check_wear = user_on(wear);


    device1_home = data.unit_data.home;
    device1_connection = data.unit_data.connection;
    device1_type = JSON.stringify(data.unit_data.type);
    write_device(device1_type, device1_home, device1_connection, 1);

});

socket.on('livedata', function(livedata){ //Funksjon som kontinuerlig hører etter data for å plotte livedata, blir sendt flere ganger i sekundet

    dataArr3.push(livedata);
    dataArr3.shift();
    label2.push(getTime());
    label2.shift();
    myLineChart3.update();
    //console.log("Livedata called")
    //process.stdout.write(".");

});

//Status på om brukeren har på armbåndet
function getstatus(state) {
    if (state === 1){
        fake_status = "Bracelet ON";
    }
    else if (state === 0){
        fake_status = "Bracelet OFF"
    }
    else if (state === 2){
        fake_status = "Bracelet Malfunction"
    }
    else {
        console.log("Something went wrong!");
    }
    document.getElementById("status").innerHTML = fake_status
    console.log("status changed");
}



//Funksjoner for kart-elementet
/*-----------------------------------------------------------------------------------------------------*/
function getgps() { //Funksjon for å hente inn koordinater og plotte map
    socket.emit("gps_allowed", 1)
    plotmap(lon, lat)
    console.log("GPS allowed called")
    console.log(device1_type)
}

function plotmap(lon, lat){
    var mapProp= {
        center:new google.maps.LatLng(lat, lon),
        zoom:13,
    };
    new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

//Indikator for signalstyrke til GPS
function update_indicator(gps_str) {
    console.log("ok")

    if (gps_str < 3){

        bar1.style.backgroundColor = "#d1002c";
        bar2.style.backgroundColor = "#d1002c";
        bar3.style.backgroundColor = "#d1002c";
        bar4.style.backgroundColor = "#d1002c";

        bar1.style.opacity = "1";
        bar2.style.opacity = "0";
        bar3.style.opacity = "0";
        bar4.style.opacity = "0";

    }
    else if (gps_str >= 3 && gps_str < 7){
        bar1.style.backgroundColor = "#d17300";
        bar2.style.backgroundColor = "#d17300";
        bar3.style.backgroundColor = "#d17300";
        bar4.style.backgroundColor = "#d17300";

        bar1.style.opacity = "1";
        bar2.style.opacity = "1";
        bar3.style.opacity = "0";
        bar4.style.opacity = "0";


    }
    else if (gps_str >= 7 && gps_str < 10){
        bar1.style.backgroundColor = "#e5cc52";
        bar2.style.backgroundColor = "#e5cc52";
        bar3.style.backgroundColor = "#e5cc52";
        bar4.style.backgroundColor = "#e5cc52";

        bar1.style.opacity = "1";
        bar2.style.opacity = "1";
        bar3.style.opacity = "1";
        bar4.style.opacity = "0";

    }
    else if (gps_str >= 10){
        bar1.style.backgroundColor = "#45c622";
        bar2.style.backgroundColor = "#45c622";
        bar3.style.backgroundColor = "#45c622";
        bar4.style.backgroundColor = "#45c622";

        bar1.style.opacity = "1";
        bar2.style.opacity = "1";
        bar3.style.opacity = "1";
        bar4.style.opacity = "1";

    }
}


//Funksjoner for flere enheter
/*-----------------------------------------------------------------------------------------------------*/

/*
socket.on('json dev2', function(data){

    device1_home = data.home;
    device1_connection = data.connection;
    device1_type = data.type;
    write_device();
});

socket.on('json dev3', function(data){

    device2_home = data.home;
    device2_connection = data.connection;
    device2_type = data.type;
    write_device();
});

socket.on('json dev4', function(data){

    device3_home = data.home;
    device3_connection = data.connection;
    device3_type = data.type;
    write_device();
});

socket.on('json dev5', function(data){

    device4_home = data.home;
    device4_connection = data.connection;
    device4_type = data.type;
    write_device();
});
*/

//Funksjon for å overskrive tekst og bilde basert på informasjon fra ESP32.

function write_device(t, h, c, no){ //t = type, h = home, c = connection, no = device no.
    no = String(no)
    if (t.toLowerCase() === "esp32") {
        let image1 = document.getElementById('dev'+no+'_pic');
        image1.src = "bilder/arduinouno1.jpg"
        image1.style = "width: 500px; margin-top: 100px; align-items: flex-end"
    }
    else if (t.toLowerCase() === "arduino") {
        let image2 = document.getElementById('dev'+no+'_pic');
        image2.src = "bilder/esp32_1.jpg"
        image2.style = "width: 400px; margin-top: 100px; align-items: flex-end"
    }
    else {
        console.log("Type not supported")
    }

    document.getElementById("device-div-"+no).style = "display: block;"
    document.getElementById("dev"+no+"_type").innerHTML = t;
    document.getElementById("dev"+no+"_home").innerHTML = h;
    document.getElementById("dev"+no+"_connection").innerHTML = c;
}