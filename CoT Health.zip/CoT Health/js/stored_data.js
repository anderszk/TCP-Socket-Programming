//Chartoperations for stored data

labelx = [1,2,3,4,51,1,2,3,3,1,2,3,21,1,2,3,23,123,12,3]
labelbar = [1,2,3,4,51,1,2,3,3,1,2,3,21,1,2,3,23,123,12,3]


var chartColors = {
    red: 'rgb(203,74,74)',
    idle: 'rgb(177,175,175)'
};

var itx = document.getElementById('chartBPM').getContext('2d'); //Defines the basic graphic element of the graph

function labelday(){
    var today = new Date();
    for (i = 0;i<20;i++) {
        var dd = String(today.getDate())
        var mm = String(today.getMonth() + 1); //January is 0!
            dd-=i
            if (dd < 1) {
                dd += 30;
                mm -= 1;
            }

            labelx.unshift(dd+"/"+mm)
            labelx.pop()

    }
}

function labelhour(){
    var today = new Date();
    for (i = 0;i<20;i++) {
        var hh = (today.getHours())
        hh-=i

        if (hh < 1) {
            hh += 24;
        }

        labelx.unshift(String(hh)+":"+"00")
        if(labelx.length < 24) {
            labelx.pop()
        }
    }
}



function labelweek(){
    var today = new Date();
    var firstDayOfYear = new Date(today.getFullYear(), 0, 1);
    var pastDaysOfYear = (today - firstDayOfYear) / 86400000;
    for (i = 0;i<20;i++) {
        var week = Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
        week-=i
        if (week < 1) {
            week += 52;
        }

        labelx.unshift("Week: "+week)
        labelx.pop()
    }
}


function label_for_bar(){
    var today = new Date();
    for (i = 0;i<31;i++) {
        var dd = String(today.getDate())
        var mm = String(today.getMonth() + 1); //January is 0!
        dd-=i
        if (dd < 1) {
            dd += 30;
            mm -= 1;
        }

        labelbar.unshift(dd+"/"+mm)
        if(labelbar.length < 30) {
            labelbar.pop()
        }
    }
}

label_for_bar();
labelhour();




var LineChart1 = new Chart(itx, { //Defines the graph
    type: 'line', //Defines the type of graph
    data: { //Decides how the data (content of the graph will be)
        labels: labelx,
        datasets: [ //Datasets refers to the different graphs and the data they contain
            {
                label: 'Slag i minuttet [BPM]', //Label of dataset/graph 1
                data: stored_bpm, //The dataArray that actually stores the data
                backgroundColor: [
                    'rgb(181,90,90)'
                ],
                borderColor: [
                    'rgb(255,0,0)'
                ],
                borderWidth: 1, //The width of the graph line
                fill: false
            },
        ]
    },
    options: {
        hoverMode: 'index',
        stacked: false,
        position: 'left',
        scales: {
            yAxes: [{
                type: 'linear',
                ticks: {
                    stepWidth: 2,
                    start: -20,
                    steps: 8,
                    gridLines: {
                        drawOnChartArea: false,
                    }
                }
            }]
        },
        responsive: true,
        maintainAspectRatio: false
    }
});




var ktx = document.getElementById('chartTemp').getContext('2d'); //Defines the basic graphic element of the graph

var LineChart2 = new Chart(ktx, { //Defines the graph
    type: 'line', //Defines the type of graph
    data: { //Decides how the data (content of the graph will be)
        labels: labelx, //Labels define the values of the x-axis (and can be altered at a later point/live)
        datasets: [ //Datasets refers to the different graphs and the data they contain
            {
                label: 'Grader Celsius [℃]',
                data: stored_temp,
                backgroundColor: [
                    'rgb(181,90,90)'
                ],
                borderColor: [
                    'rgb(255,0,0)'
                ],
                borderWidth: 1,
                fill: false,
                yAxisID: 'A'
            },
            {
                label: 'Luftfuktighet [%]',
                data: stored_humidity,
                backgroundColor: [
                    'rgb(90,110,181)'
                ],
                borderColor: [
                    'rgb(0,115,255)'
                ],
                borderWidth: 1,
                fill: false,
                yAxisID: 'B'
            }
        ]
    },
    options: {
        scales: {
            yAxes: [{
                id: 'A',
                position: 'left',
                ticks: {
                    beginAtZero: true //Keep this true to begin at zero in the graph
                }
            },
            {
                id: 'B',
                position: 'right',
            }]
        },
        responsive: true,
        maintainAspectRatio: false,
        hoverMode: 'index',
        stacked: false,
    }
});




var ltx = document.getElementById('chartUsage').getContext('2d'); //Defines the basic graphic element of the graph

var LineChart3 = new Chart(ltx, { //Defines the graph
    type: 'bar', //Defines the type of graph
    data: { //Decides how the data (content of the graph will be)
        labels: labelbar, //Labels define the values of the x-axis (and can be altered at a later point/live)
        datasets: [ //Datasets refers to the different graphs and the data they contain
            {
                label: 'Bruk [Timer]',
                data: stored_usage,
                backgroundColor: [
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                    chartColors.idle,
                ],
            }
        ]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true //Keep this true to begin at zero in the graph
                }
            }]
        },
        responsive: true,
        maintainAspectRatio: false,
        hoverMode: 'index',
        stacked: false,
    }
});


var colorChangeValue = 10; //set this to whatever is the deciding color change value
var dataset = LineChart3.data.datasets[0];
for (var i = 0; i < dataset.data.length; i++) {
    if (dataset.data[i] >= colorChangeValue) {
        dataset.backgroundColor[i] = chartColors.red;
    }
}
LineChart3.update();


/*For BPM*/
/*-----------------------------------------------------------------------------------------------------*/


function hourbtn1(){ //When pressing the button: changes labels and changes data to hourly
    labelhour();
    for (i=0;i<20;i++){
        stored_bpm.push(Math.floor(Math.random() * 50)+60);
        stored_bpm.shift();
    }
    LineChart1.update()
}


function daybtn1(){ //When pressing the button: changes labels and data to daily
    labelday();
    for (i=0;i<20;i++){
        stored_bpm.push(Math.floor(Math.random() * 50)+60);
        stored_bpm.shift();
    }
    LineChart1.update()
}


function weekbtn1() { //When pressing the button: changes labels and data to weekly
    labelweek();
    for (i=0;i<20;i++) {
        stored_bpm.push(Math.floor(Math.random() * 50) + 60);
        stored_bpm.shift()
    }
    LineChart1.update()
}


/*For Temperature*/
/*-----------------------------------------------------------------------------------------------------*/


function hourbtn2(){ //When pressing the button: changes labels and changes data to hourly
    labelhour();
    for (i=0;i<20;i++){
        stored_temp.push(Math.floor(Math.random() * 20));
        stored_temp.shift();
        stored_humidity.push(Math.floor(Math.random() * 30)+65);
        stored_humidity.shift();
    }
    LineChart2.update()
}


function daybtn2(){ //When pressing the button: changes labels and data to daily
    labelday();
    for (i=0;i<20;i++){
        stored_temp.push(Math.floor(Math.random() * 20));
        stored_temp.shift();
        stored_humidity.push(Math.floor(Math.random() * 30)+65);
        stored_humidity.shift();
    }
    LineChart2.update()
}


function weekbtn2() { //When pressing the button: changes labels and data to weekly
    labelweek();
    for (i=0;i<20;i++){
        stored_temp.push(Math.floor(Math.random() * 20));
        stored_temp.shift();
        stored_humidity.push(Math.floor(Math.random() * 30)+65);
        stored_humidity.shift();
    }
    LineChart2.update()
}


/*For Usage*/
/*-----------------------------------------------------------------------------------------------------*/
/*


function hourbtn3(){ //When pressing the button: changes labels and changes data to hourly
    labelhour();
    for (i=0;i<20;i++){
        stored_usage.push(Math.floor(Math.random() * 50)+60);
        stored_usage.shift();
    }
    LineChart3.update()
}


function daybtn3(){ //When pressing the button: changes labels and data to daily
    labelday();
    for (i=0;i<20;i++){
        stored_usage.push(Math.floor(Math.random() * 50)+60);
        stored_usage.shift();
    }
    LineChart3.update()
}


function weekbtn3() { //When pressing the button: changes labels and data to weekly
    labelweek();
    for (i=0;i<20;i++){
        stored_usage.push(Math.floor(Math.random() * 50)+60);
        stored_usage.shift();
    }
    LineChart3.update()
}

 */



//Google maps
/*-----------------------------------------------------------------------------------------------------*/


coor = new google.maps.LatLng(stored_lat, stored_lon)

var mapProp= {
    center: coor,
    zoom:15,
};

var marker = new google.maps.Marker({
    position:coor,
    title: "Bruker"
});

var map = new google.maps.Map(document.getElementById("stored-gps"),mapProp);
marker.setMap(map)


/*-----------------------------------------------------------------------------------------------------*/

//Function for infobox

function info_device() {

    $("#info-loc").hide();
    $("#info-dev").hide();
    $("#info-con").hide();
    $("#info-time").hide();
    $("#info1").hide();
    $("#info2").hide();
    $("#info3").hide();
    $("#info4").hide();

    var today = new Date();
    var date = today.getDate()+"."+(today.getMonth()+1)+"."+today.getFullYear();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime ="Dato: "+ date+' <br> '+"Tid: "+time;


    var last_connected = dateTime;
    /*
    var device = device1_type;
    var connection = device1_connection;
    var location = device1_home;
     */

    var device = "ESP32";
    var connection = "WiFi";
    var location = "Drammen";


    document.getElementById("info-loc").innerHTML = location;
    document.getElementById("info-dev").innerHTML = device;
    document.getElementById("info-con").innerHTML = connection;
    document.getElementById("info-time").innerHTML = last_connected;

    $("#info-loc").fadeIn();
    $("#info-dev").fadeIn();
    $("#info-con").fadeIn();
    $("#info-time").fadeIn();

    var new1 = "Lokasjon: "
    var new2 = "Enhet: "
    var new3 = "Tilkobling: "
    var new4 = "Sist pålogget: "

    document.getElementById("info1").innerHTML = new1;
    document.getElementById("info2").innerHTML = new2;
    document.getElementById("info3").innerHTML = new3;
    document.getElementById("info4").innerHTML = new4;

    $("#info1").fadeIn();
    $("#info2").fadeIn();
    $("#info3").fadeIn();
    $("#info4").fadeIn();


}

function info_user() {
    $("#info-loc").hide();
    $("#info-dev").hide();
    $("#info-con").hide();
    $("#info-time").hide();
    $("#info1").hide();
    $("#info2").hide();
    $("#info3").hide();
    $("#info4").hide();

    var name = "Sacit Ali Senkaya"
    var age = "20 Years"
    /*
    var peak = peakbpm;
    var temp = peaklow+"/"+peakhigh
     */
    var peak = 120;

    var high = 5;
    var low = -12;
    var temp = "Laveste temperatur: "+low+"℃ <br>"+"Høyeste temperatur: "+high+"℃";


    document.getElementById("info-loc").innerHTML = name;
    document.getElementById("info-dev").innerHTML = age;
    document.getElementById("info-con").innerHTML = peak;
    document.getElementById("info-time").innerHTML = temp;

    $("#info-loc").fadeIn();
    $("#info-dev").fadeIn();
    $("#info-con").fadeIn();
    $("#info-time").fadeIn();


    var new1 = "Navn: "
    var new2 = "Alder: "
    var new3 = "Peak BPM: "
    var new4 = "Temperatur Lav/Høy"



    document.getElementById("info1").innerHTML = new1;
    document.getElementById("info2").innerHTML = new2;
    document.getElementById("info3").innerHTML = new3;
    document.getElementById("info4").innerHTML = new4;

    $("#info1").fadeIn();
    $("#info2").fadeIn();
    $("#info3").fadeIn();
    $("#info4").fadeIn();

}



